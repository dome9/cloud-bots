## LOCAL TESTING
from index import * 

#sample event
event = {
    'Records': [{
        'EventSource': 'aws:sns',
        'EventVersion': '1.0',
        'EventSubscriptionArn': 'arn:aws:sns:us-west-2:621958466464:eventsToSlack:0cf0e80c-1fef-4421-9cc0-b3c102ac7836',
        'Sns': {
            'Type': 'Notification',
            'MessageId': 'd59748d6-f529-532f-bf13-1a1e438fde5c',
            'TopicArn': 'arn:aws:sns:us-west-2:621958466464:eventsToSlack',
            'Subject': 'Dome9 Continuous compliance: Entity status change detected',
            'Message': '{"Policy":{"Name":"*remediationv3","Description":""},"Bundle":{"Name":"* Remediation bundle v2","Description":""},"ReportTime":"2018-01-04T23:10:27.612Z","Rule":{"Name":"Buckets should not be publicly accessable","Description":"a security used rules.","Remediation":" the Dome9 Report.","ComplianceTags":"CIS Section 1.1.7| AUTO: s3_delete_permissions","Severity":"High"},"Status":"Failed","Account":{"Id":"621958466464","Vendor":"Aws"},"Region":"Oregon","Entity":{"description":"deeeme","inboundRules":[],"outboundRules":[{"protocol":"ALL","port":0,"portTo":0,"scope":"0.0.0.0/0","scopeMetaData":null}],"networkAssetsStats":[{"type":"ELBs","count":0},{"type":"instances","count":0},{"type":"RDSs","count":0},{"type":"LambdaFunctions","count":0},{"type":"Redshifts","count":0},{"type":"ApplicationLoadBalancers","count":0},{"type":"EFSs","count":0},{"type":"ElastiCacheClusters","count":0}],"isProtected":false,"vpc":{"cloudAccountId":"89ff48fc-9c8b-4292-a169-d6e938af2dd2","cidr":"10.0.0.0/16","Region":5,"Id":"vpc-c037c1b9","AccountNumber":"621958466464","vpnGateways":[],"internetGateways":[{"externalId":"igw-e49a6d82","vpcAttachments":[{"state":"available","vpcId":"vpc-c037c1b9"}],"name":""}],"dhcpOptionsId":"dopt-b18786d5","instanceTenancy":"default","isDefault":false,"state":"available","tags":{},"name":"testDeleteMe","source":1},"Id":"alexremediatebucketbbbb","Type":"SecurityGroup","Name":"test2222","Dome9Id":"2398817","AccountNumber":"621958466464","Region":"us_west_2","source":"db","tags":[]}}',
            'Timestamp': '2018-01-04T23:10:30.652Z',
            'SignatureVersion': '1',
            'Signature': 'fKnhCGtvNIKIKslbL54A2ZjIiGc/NPw==',
            'SigningCertUrl': 'https://sns.us-west-2.amazonaws.com/SimpleNotificationService-433026a4050d206028891664da859041.pem',
            'UnsubscribeUrl': 'https://sns.us-west-2.amazonaws.com/?Action=Unsubscribe&SubscriptionArn=arn:aws:sns:us-west-2:621958466464:eventsToSlack:0cf0e80c-1fef-4421-9cc0-b3c102ac7836',
            'MessageAttributes': {}
        }
    }]
}



#export SNS_TOPIC_ARN="arn:aws:sns:us-west-2:621958466464:eventsToSlack"
SNS_TOPIC_ARN = "arn:aws:sns:us-west-2:621958466464:eventsToSlack"

context = ""


lambda_handler(event,context)