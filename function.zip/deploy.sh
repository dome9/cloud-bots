rm function.zip 
zip -r -X function.zip *
aws lambda update-function-code --function-name remediation_actions --zip-file fileb://function.zip --profile staging-demo
